

<?php $__env->startSection('title'); ?>
    Lilliefors
<?php $__env->stopSection(); ?>

<?php $__env->startSection('alamat'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('alamat-aktif'); ?>
    Statistik Deskriptif / Lilliefors
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="jumbotron jumbotron-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header text-center border-0">
                        <p class="h3">Liliefors</p>
                    </div>
                    <div class="card-body">
                        <table class="table table-light text-center table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Yi</th>
                                    <th>Frekuensi</th>
                                    <th>Fkum</th>
                                    <th>Zi</th>
                                    <th>F(Zi)</th>
                                    <th>S(Zi)</th>
                                    <th>|F(Zi)-S(Zi)|</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php for($i = 0; $i < $banyakData; $i++): ?>

                                    <tr>
                                        <th> <?php echo e($i + 1); ?></th>
                                        <td> <?php echo e($frekuensi[0][$i]->skor); ?></td>
                                        <td> <?php echo e($frekuensi[0][$i]->frekuensi); ?></td>
                                        <td> <?php echo e($fkum2[$i]); ?></td>
                                        <td> <?php echo e($Zi[$i]); ?></td>
                                        <td> <?php echo e($fZi[$i]); ?></td>
                                        <td> <?php echo e($sZi[$i]); ?></td>
                                        <td> <?php echo e($lilliefors[$i]); ?></td>
                                    </tr>
                                <?php endfor; ?>
                                <tr class="text-bold">
                                    <td>Total:</td>
                                    <td></td>
                                    <td><?php echo e($n); ?></td>
                                    <td><?php echo e($n); ?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td> <?php echo e($totalLillie); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\statistik_laravel\resources\views//lilliefors.blade.php ENDPATH**/ ?>