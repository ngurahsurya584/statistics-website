

<?php $__env->startSection('title'); ?>
    Uji Anava
<?php $__env->stopSection(); ?>

<?php $__env->startSection('alamat'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('alamat-aktif'); ?>
    Statistik Deskriptif / Uji Anava
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="jumbotron jumbotron-fluid mt-5">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="d-flex justify-content-end">
                        <a href="/exportAnava" class="btn btn-danger mt-2 mb-2 mr-3">
                            Export
                        </a>
                        <a href="#" class="btn btn-success mt-2 mb-2" data-toggle="modal" data-target="#ujitberkolerasi">
                            Import Uji Anava
                        </a>
                        <!-- Modal -->
                        <div class="modal fade" id="ujitberkolerasi" tabindex="-1" role="dialog"
                            aria-labelledby="ujitberkolerasi" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Import File Uji Anava</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <form action="/importAnava" method="POST" enctype="multipart/form-data">
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <input type="file" name="file" required>
                                                <p class="mt-1"> <i>File yang disupport: .xlxs</i> </p>
                                            </div>

                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Tutup</button>
                                                <button type="submit" class="btn btn-primary">Import</button>
                                                <?php echo csrf_field(); ?>

                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card ">
                        <div class="card-header text-center border-0 ">
                            <p class="h3">Masukkan Data</p>
                        </div>
                        <div class="card-body">
                            <form method="post" action="/ujiAnava" id="forminput"> 
                                <div class="form-group">
                                    <label for="input1">Input X1</label>
                                    <input required type="text" class="form-control mb-2" placeholder="Masukkan Nilai X1"
                                        name="x1" value="<?php echo e(old('x1')); ?>">
                                    <label for="input2">Input X2</label>
                                    <input required type="text" class="form-control mb-2" placeholder="Masukkan Nilai X2"
                                        name="x2" value="<?php echo e(old('x2')); ?>">
                                    <label for="input3">Input X3</label>
                                    <input required type="text" class="form-control mb-2" placeholder="Masukkan Nilai X3"
                                        name="x3" value="<?php echo e(old('x3')); ?>">
                                    <label for="input4">Input X4</label>
                                    <input required type="text" class="form-control mb-2" placeholder="Masukkan Nilai X4"
                                        name="x4" value="<?php echo e(old('x4')); ?>">


                                    <?php if($errors->has('x1')): ?>
                                        <div class="alert alert-danger"><?php echo e($errors->first('x1')); ?></div>
                                    <?php endif; ?>

                                    <?php if($errors->has('x2')): ?>
                                        <div class="alert alert-danger"><?php echo e($errors->first('x2')); ?></div>
                                    <?php endif; ?>

                                    <?php if($errors->has('x3')): ?>
                                        <div class="alert alert-danger"><?php echo e($errors->first('x3')); ?></div>
                                    <?php endif; ?>

                                    <?php if($errors->has('x4')): ?>
                                        <div class="alert alert-danger"><?php echo e($errors->first('x4')); ?></div>
                                    <?php endif; ?>


                                </div>
                                <input type="submit" class="btn btn-primary daftar-btn mt-4" name="submit" value="Input">
                                

                                <?php echo csrf_field(); ?>

                                <?php if(session('status')): ?>
                                    <p></p>
                                    <div class="alert alert-success">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                <?php endif; ?>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-11">
                    <div class="card">
                        <div class="card-header text-center border-0 ">
                            <p class="h3">Uji Anava</p>
                        </div>
                        <div class="card-body">
                            <table class="table table-light text-center table-bordered">
                                <thead class="text-center">
                                    <tr>
                                        <th class="w-25">No</th>
                                        <th>X1</th>
                                        <th>X2</th>
                                        <th>X3</th>
                                        <th>X4</th>
                                        <th>X1^2</th>
                                        <th>X2^2</th>
                                        <th>X3^2</th>
                                        <th>X4^2</th>
                                        <th>Xt</th>
                                        <th>Xt^2</th>
                                        <th> Aksi</th>
                                    </tr>
                                </thead>
                                <tbody class="text-center">
                                    <?php for($i = 0; $i < $jumlahData; $i++): ?>
                                        <tr>
                                        <tr>
                                            <th><?php echo e($i + 1); ?></th>
                                            <td><?php echo e($ujiAnava[$i]->x1); ?></td>
                                            <td><?php echo e($ujiAnava[$i]->x2); ?></td>
                                            <td><?php echo e($ujiAnava[$i]->x3); ?></td>
                                            <td><?php echo e($ujiAnava[$i]->x4); ?></td>
                                            <td><?php echo e($x1kuadrat[$i]); ?></td>
                                            <td><?php echo e($x2kuadrat[$i]); ?></td>
                                            <td><?php echo e($x3kuadrat[$i]); ?></td>
                                            <td><?php echo e($x4kuadrat[$i]); ?></td>
                                            <td><?php echo e($xtotal[$i]); ?></td>
                                            <td><?php echo e($xtotalkuadrat[$i]); ?></td>
                                            <td>
                                                <form name="delete" action="/hapusAnava/<?php echo e($ujiAnava[$i]->id); ?>"
                                                    method="POST">
                                                    
                                                    <?php echo csrf_field(); ?> 
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-outline-danger"><img
                                                            src="<?php echo e(asset('template_admin/')); ?>/img/delete.png"
                                                            alt=""></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endfor; ?>
                                </tbody>
                                <tr class="text-center">
                                    <th> Sigma: </th>
                                    <th> <?php echo e($sumX1); ?> </th>
                                    <th> <?php echo e($sumX2); ?></th>
                                    <th> <?php echo e($sumX3); ?></th>
                                    <th> <?php echo e($sumX4); ?></th>
                                    <th><?php echo e($sigmaX1kuadrat); ?></th>
                                    <th><?php echo e($sigmaX2kuadrat); ?></t>
                                    <th><?php echo e($sigmaX3kuadrat); ?></th>
                                    <th><?php echo e($sigmaX4kuadrat); ?></th>
                                    <th><?php echo e($sumxtotal); ?></th>
                                    <th><?php echo e($sumxtotalkuadrat); ?></th>
                                </tr>
                                <tr class="text-center">
                                    <th> Rata-Rata: </th>
                                    <th><?php echo e($avgX1); ?></th>
                                    <th><?php echo e($avgX2); ?></th>
                                    <th><?php echo e($avgX3); ?></th>
                                    <th><?php echo e($avgX4); ?></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-11">
                    <div class="card">
                        <div class="card-header border-0">
                            <p class="h3">Tabel Uji Anava</p>
                        </div>
                        <div class="card-body">
                            <table class="table">
                                <thead class="text-center">
                                    <tr>
                                        <th>Sumber Variasi</th>
                                        <th>JK</th>
                                        <th>DK</th>
                                        <th>RJK</th>
                                        <th>FHitung</th>
                                        <th>Ftabel (5%)</th>
                                        <th>Keterangan</th>
                                    </tr>
                                </thead>
                                <tbody class="text-center">
                                    <tr>
                                        <th>Antar :</th>
                                        <td><?php echo e(number_format($JKA, 2)); ?></td>
                                        <td><?php echo e(number_format($DKA, 2)); ?></td>
                                        <td><?php echo e(number_format($RJKA, 2)); ?></td>
                                        <td><?php echo e(number_format($F, 2)); ?></td>
                                        <td> <?php echo e($fTabel); ?> </td>
                                        <td> <?php echo e($status); ?></td>
                                    </tr>
                                </tbody>
                                <tr class="text-center">
                                    <th>Dalam :</th>
                                    <td><?php echo e(number_format($jkd, 2)); ?></td>
                                    <td><?php echo e(number_format($dkd, 2)); ?></td>
                                    <td><?php echo e(number_format($rjkd, 2)); ?></td>
                                    <td> - </td>
                                    <td> - </td>
                                    <td></td>
                                </tr>
                                <tr class="text-center">
                                    <th>Total :</th>
                                    <td><?php echo e(number_format($jkt, 2)); ?></td>
                                    <td><?php echo e(number_format($dkt, 2)); ?></td>
                                    <td> - </td>
                                    <td> - </td>
                                    <td> - </td>
                                    <td></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\statistik_laravel\resources\views//ujiAnava.blade.php ENDPATH**/ ?>