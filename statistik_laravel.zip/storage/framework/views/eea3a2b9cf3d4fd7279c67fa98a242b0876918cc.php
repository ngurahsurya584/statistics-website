

<?php $__env->startSection('title'); ?>
    Chi-Kuadrat
<?php $__env->stopSection(); ?>

<?php $__env->startSection('alamat'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('alamat-aktif'); ?>
    Statistik Deskriptif / Chi-Kuadrat
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="jumbotron jumbotron-fluid">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header text-center border-0">
                        <p class="h3">Chi Kuadrat</p>
                    </div>
                    <div class="card-body">
                        <table class="table table-light text-center table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Rentangan</th>
                                    <th>f0</th>
                                    <th>Batas Bawah Kelas</th>
                                    <th>Batas Atas Kelas</th>
                                    <th>Batas Bawah Z</th>
                                    <th>Batas Atas Z</th>
                                    <th>Z Tabel Bawah</th>
                                    <th>Z Tabel Atas</th>
                                    <th>L/Proporsi</th>
                                    <th>L*N (fe)</th>
                                    <th>(f0-fe)^2/fe</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php for($i = 0; $i < $kelas; $i++): ?>

                                    <tr>
                                        <th> <?php echo e($i + 1); ?> </th>
                                        <td> <?php echo e($data[$i]); ?></td>
                                        <td> <?php echo e($frekuensi[$i]); ?></td>
                                        <td> <?php echo e($batasBawahBaru[$i]); ?></td>
                                        <td> <?php echo e($batasAtasBaru[$i]); ?></td>
                                        <td> <?php echo e($zBawah[$i]); ?></td>
                                        <td> <?php echo e($zAtas[$i]); ?></td>
                                        <td> <?php echo e($zTabelBawahFix[$i]); ?></td>
                                        <td> <?php echo e($zTabelAtasFix[$i]); ?></td>
                                        <td> <?php echo e($lprop[$i]); ?></td>
                                        <td> <?php echo e($fe[$i]); ?></td>
                                        <td> <?php echo e($kai[$i]); ?></td>
                                    </tr>

                                <?php endfor; ?>
                                <tr>
                                    <th> Total: </th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th><?php echo e($totalchi); ?></th>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\statistik_laravel\resources\views/chi-normalisasi.blade.php ENDPATH**/ ?>