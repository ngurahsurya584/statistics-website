

<?php $__env->startSection('title'); ?>
    Edit Data 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('alamat'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('alamat-aktif'); ?>
    Edit Data
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>                      
    <div class="content">
        <div class="container-fluid">            
            <div class="row justify-content-center mt-4">
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-body">
                        <form method="POST" action="/edit/<?php echo e($anggota->id); ?> id="forminput">   
                        <?php echo csrf_field(); ?>                   
                        <?php echo method_field('PUT'); ?>              
                          
                            <div class="form-group">
                                <label for="input2">Skor</label>
                                <input type="text" class="form-control mb-2" value="<?php echo e($anggota->skor); ?>" id="skor"
                                    placeholder="Skor" name="skor">

                                    <?php if($errors->has('skor')): ?>
                                        <div class="alert alert-danger"><?php echo e($errors->first('skor')); ?></div>
                                    <?php endif; ?>
                                    
                            </div>                
                                  
                            <div class="d-flex">
                                <a href='/' class="btn btn-danger">Batal Edit</a>
                                <input type="submit" class="btn btn-success ml-auto p-2" name="submit" value="Edit">                                        
                            </div>
                            
                        </form>
                        </div>
                    </div>                  
                </div>
            </div>
        </div>            
    </div>
          <!-- /.container-fluid -->                                       
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\latihanlaravel\resources\views/edit.blade.php ENDPATH**/ ?>