

<?php $__env->startSection('title'); ?>
    Korelasi Point Moment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('alamat'); ?>
   Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('alamat-aktif'); ?>
    Statistik Deskriptif / Korelasi Point Moment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="d-flex justify-content-end">
            <a href="/exportmoment" class="btn btn-danger mt-2 mb-2 mr-3">
                Export
            </a>
            <a href="#" class="btn btn-success mt-2 mb-2" data-toggle="modal" data-target="#korelasiModal">
                Import Korelasi Moment
            </a>
            <!-- Modal -->
            <div class="modal fade" id="korelasiModal" tabindex="-1" role="dialog" aria-labelledby="korelasiModal" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Import File Korelasi Moment</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="/importmoment" method="POST" enctype="multipart/form-data">                                    
                            <div class="modal-body">                                                                                     
                                <div class="form-group">                                
                                <input type="file" name="file" required>
                                <p class="mt-1"> <i>File yang disupport: .xlxs dan .csv</i> </p> 
                                </div>    
                                
                                <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                <button type="submit" class="btn btn-primary">Import</button>
                                <?php echo csrf_field(); ?> 
                                
                                </div>  
                            </div>
                        </form>                                        
                    </div>
                </div>
            </div>
        </div>
        <div class="card">             
            <div class="card-header border-0">
                <p class="h3">Korelasi Point Moment</p>                
            </div>
            <?php if(session('status')): ?>                                    
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <div class="card-body">                
                <table class="table text-center">                            
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>X</th>
                            <th>Y</th>
                            <th>x</th>                           
                            <th>y</th>
                            <th>x^2</th> 
                            <th>y^2</th>
                            <th>xy</th>                              
                        </tr>                        
                    </thead>            
                    <tbody> 
                        <?php for($i = 0; $i < $jumlahData; $i++): ?>                       
                        <tr>      
                            
                                
                            <th><?php echo e($i+1); ?></th>                                                                                         
                            <td><?php echo e($moments[$i]->x); ?></td>
                            <td><?php echo e($moments[$i]->y); ?></td>                                         
                            <td><?php echo e($xKecil[$i]); ?></td>                                         
                            <td><?php echo e($yKecil[$i]); ?></td>                                         
                            <td><?php echo e($xKuadrat[$i]); ?></td>                                         
                            <td><?php echo e($yKuadrat[$i]); ?></td>                                         
                            <td><?php echo e($xKaliY[$i]); ?></td>                                   
                        </tr>                                                       
                        <?php endfor; ?>
                        <tr>
                            <th> Jumlah: </th>
                            <th> <?php echo e($sumX); ?></th>
                            <th> <?php echo e($sumY); ?> </th>
                            <th></th>
                            <th></th>
                            <th> <?php echo e($sumXKuadrat); ?></th>
                            <th> <?php echo e($sumYKuadrat); ?></th>
                            <th> <?php echo e($sumXY); ?></th>
                        </tr> 
                        <tr>
                            <th>Rata-Rata: </th>    
                            <th> <?php echo e(number_format($rata2X,2)); ?></th>
                            <th> <?php echo e(number_format($rata2Y,2)); ?></th>
                        </tr>                       
                    </tbody>                    
                </table>                     
                <table class="table text-left">
                    <tr>
                        <td> <b> Nilai Korelasi Point Moment : </b> &nbsp <?php echo e($korelasimoment); ?> </td>     
                    </tr>    
                </table>                                                     
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\latihanlaravel\resources\views//korelasimoment.blade.php ENDPATH**/ ?>