

<?php $__env->startSection('title'); ?>
    Korelasi Point Moment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('alamat'); ?>
   Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('alamat-aktif'); ?>
    Statistik Deskriptif / Korelasi Point Moment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header border-0">
                <p class="h3">Korelasi Point Moment</p>                
            </div>
            <div class="card-body">                
                <table class="table text-center">                            
                    <thead>
                        <tr>
                            <th>X</th>
                            <th>Y</th>
                            <th>x</th>                           
                            <th>y</th>
                            <th>x^2</th> 
                            <th>y^2</th>
                            <th>xy</th>  
                        </tr>                        
                    </thead>            
                    <tbody>
                            <td><?php echo e($hello); ?></td>
                            <td></td>                                         
                            <td></td>                                         
                            <td></td>                                         
                            <td></td>                                         
                            <td></td>                                         
                            <td></td>                                         
                    </tbody>
                </table>                                                               
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\latihanlaravel\resources\views//korelasiMoment.blade.php ENDPATH**/ ?>