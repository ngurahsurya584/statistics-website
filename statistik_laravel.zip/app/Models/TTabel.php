<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TTabel extends Model
{
    protected $table = 'tb_t';  
    use HasFactory;
}