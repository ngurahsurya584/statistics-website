<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FTabel extends Model
{
    protected $table = 'tb_f';  
    use HasFactory;
}